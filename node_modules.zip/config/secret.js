module.exports={
    'secret':'rahasiaku', 
}